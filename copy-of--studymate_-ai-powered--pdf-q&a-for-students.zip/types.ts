
export interface PdfFile {
  name: string;
  size: number;
}

export interface Citation {
  document: string;
  page: number;
  snippet: string;
}

export enum ChatRole {
    USER = 'user',
    AI = 'ai',
    SYSTEM = 'system',
}

export interface ChatMessage {
  role: ChatRole;
  content: string;
  citations: Citation[];
}

export interface AiResponse {
  answer: string;
  citations: Citation[];
}

export interface User {
  username: string;
  email: string;
  phoneNumber?: string;
}

export interface TopicSummary {
  topic: string;
  summary: string;
}
