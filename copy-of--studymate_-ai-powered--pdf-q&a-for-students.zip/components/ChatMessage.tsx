
import React from 'react';
import { ChatMessage, ChatRole } from '../types';
import { BotIcon } from './icons/BotIcon';
import { UserIcon } from './icons/UserIcon';
import { PdfIcon } from './icons/PdfIcon';

interface ChatMessageItemProps {
  message?: ChatMessage;
  isLoading?: boolean;
}

const LoadingIndicator: React.FC = () => (
    <div className="flex items-center space-x-2">
        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-pulse [animation-delay:-0.3s]"></div>
        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-pulse [animation-delay:-0.15s]"></div>
        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-pulse"></div>
    </div>
);

const formatContent = (text: string) => {
  // Simple markdown-like bold formatter
  const boldRegex = /\*\*(.*?)\*\*/g;
  // Basic HTML escaping for safety, although we control the input source
  const escapedText = text.replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const html = escapedText.replace(boldRegex, '<strong>$1</strong>');
  return { __html: html };
};

const ChatMessageItem: React.FC<ChatMessageItemProps> = ({ message, isLoading = false }) => {
  if (isLoading) {
    return (
      <div className="flex items-start space-x-3">
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
            <BotIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />
        </div>
        <div className="bg-white dark:bg-gray-700 rounded-lg p-3">
          <LoadingIndicator />
        </div>
      </div>
    );
  }

  if (!message) return null;

  const isUser = message.role === ChatRole.USER;
  const isSystem = message.role === ChatRole.SYSTEM;

  if (isSystem) {
    return (
        <div className="text-center my-2">
            <p className="text-xs text-gray-500 dark:text-gray-400 italic bg-gray-200 dark:bg-gray-700/50 rounded-full px-3 py-1 inline-block">{message.content}</p>
        </div>
    );
  }

  const icon = isUser ? (
    <UserIcon className="w-5 h-5 text-white" />
  ) : (
    <BotIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />
  );

  const iconBg = isUser ? 'bg-indigo-500' : 'bg-gray-200 dark:bg-gray-700';
  const messageBg = isUser ? 'bg-indigo-500 text-white' : 'bg-white dark:bg-gray-700';
  const containerClass = isUser ? 'flex-row-reverse' : 'flex-row';

  return (
    <div className={`flex items-start space-x-3 space-x-reverse ${containerClass}`}>
      <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${iconBg}`}>
        {icon}
      </div>
      <div className={`max-w-xl rounded-lg p-3 shadow-sm ${messageBg}`}>
        <p
            className="text-sm whitespace-pre-wrap"
            dangerouslySetInnerHTML={formatContent(message.content)}
        />
        {message.citations.length > 0 && (
          <div className="mt-3 pt-3 border-t border-gray-300 dark:border-gray-600">
            <h4 className="text-xs font-semibold mb-2">Sources:</h4>
            <div className="space-y-2">
              {message.citations.map((citation, index) => (
                <div key={index} className="p-2 rounded-md bg-gray-100 dark:bg-gray-600 text-gray-800 dark:text-gray-200">
                  <div className="flex items-center text-xs font-medium mb-1">
                    <PdfIcon className="w-4 h-4 mr-1 text-red-500" />
                    <span>{citation.document} (p. {citation.page})</span>
                  </div>
                  <p className="text-xs italic text-gray-600 dark:text-gray-400">"{citation.snippet}"</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatMessageItem;
