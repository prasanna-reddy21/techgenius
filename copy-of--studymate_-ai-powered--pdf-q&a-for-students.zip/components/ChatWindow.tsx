
import React, { useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import ChatMessageItem from './ChatMessage';
import MessageInput from './MessageInput';

interface ChatWindowProps {
  messages: ChatMessage[];
  isLoading: boolean;
  onSendMessage: (message: string) => void;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading, onSendMessage }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  return (
    <div className="flex-1 flex flex-col h-full bg-gray-50 dark:bg-gray-800/50">
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full">
                <p className="text-gray-500 dark:text-gray-400">Upload a PDF to start chatting.</p>
            </div>
        ) : (
             messages.map((msg, index) => (
                <ChatMessageItem key={index} message={msg} />
            ))
        )}
        {isLoading && <ChatMessageItem isLoading={true} />}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-4 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
        <MessageInput onSendMessage={onSendMessage} isLoading={isLoading} />
      </div>
    </div>
  );
};

export default ChatWindow;
