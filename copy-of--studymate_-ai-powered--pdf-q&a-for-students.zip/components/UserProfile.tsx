import React from 'react';
import { User } from '../types';
import { UserIcon } from './icons/UserIcon';
import { LogoutIcon } from './icons/LogoutIcon';

interface UserProfileProps {
  user: User;
  onLogout: () => void;
}

const UserProfile: React.FC<UserProfileProps> = ({ user, onLogout }) => {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center min-w-0">
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
          <UserIcon className="w-6 h-6 text-gray-600 dark:text-gray-400" />
        </div>
        <div className="ml-3 min-w-0">
            <p className="text-sm font-semibold text-gray-800 dark:text-gray-200 truncate" title={user.username}>
            {user.username}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400 truncate" title={user.email}>
            {user.email}
            </p>
        </div>
      </div>
      <button
        onClick={onLogout}
        className="ml-2 p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600 hover:text-gray-700 dark:hover:text-gray-200 transition-colors"
        title="Logout"
        aria-label="Logout"
      >
        <LogoutIcon className="w-5 h-5" />
      </button>
    </div>
  );
};

export default UserProfile;
