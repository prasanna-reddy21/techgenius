
import React from 'react';
import { PdfFile } from '../types';
import { PdfIcon } from './icons/PdfIcon';

interface PdfListProps {
  files: PdfFile[];
  onRemoveFile: (fileName: string) => void;
}

const PdfList: React.FC<PdfListProps> = ({ files, onRemoveFile }) => {
  if (files.length === 0) {
    return (
      <div className="text-center py-10">
        <p className="text-sm text-gray-500 dark:text-gray-400">No documents uploaded yet.</p>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-lg font-semibold mb-2 text-gray-700 dark:text-gray-300">Uploaded Documents</h2>
      <ul className="space-y-2">
        {files.map((file, index) => (
          <li
            key={index}
            className="flex items-center justify-between bg-gray-50 dark:bg-gray-700 p-2 rounded-md group"
          >
            <div className="flex items-center min-w-0">
                <PdfIcon className="w-5 h-5 text-red-500 flex-shrink-0" />
                <span className="ml-2 text-sm font-medium text-gray-800 dark:text-gray-200 truncate" title={file.name}>
                {file.name}
                </span>
            </div>
            <button
                onClick={() => onRemoveFile(file.name)}
                className="ml-2 p-1 rounded-full text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600 hover:text-gray-600 dark:hover:text-gray-200 opacity-0 group-hover:opacity-100 transition-opacity"
                title={`Remove ${file.name}`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PdfList;
