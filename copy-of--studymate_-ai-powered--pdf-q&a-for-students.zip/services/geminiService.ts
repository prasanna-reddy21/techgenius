
import { GoogleGenAI, Type } from "@google/genai";
import { AiResponse, Citation, TopicSummary } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    answer: {
      type: Type.STRING,
      description: "A detailed, comprehensive answer to the user's question, synthesized from the provided document context."
    },
    citations: {
      type: Type.ARRAY,
      description: "A list of sources used to formulate the answer.",
      items: {
        type: Type.OBJECT,
        properties: {
          document: {
            type: Type.STRING,
            description: "The name of the source PDF document."
          },
          page: {
            type: Type.INTEGER,
            description: "The page number within the document where the information was found."
          },
          snippet: {
            type: Type.STRING,
            description: "A brief, relevant quote or snippet from the document that supports the answer."
          }
        },
        required: ["document", "page", "snippet"]
      }
    }
  },
  required: ["answer", "citations"]
};

const summarySchema = {
  type: Type.OBJECT,
  properties: {
    topics: {
      type: Type.ARRAY,
      description: "A list of key topics and their summaries found in the document.",
      items: {
        type: Type.OBJECT,
        properties: {
          topic: {
            type: Type.STRING,
            description: "The name of a main topic or chapter."
          },
          summary: {
            type: Type.STRING,
            description: "A concise summary of the content related to this topic."
          }
        },
        required: ["topic", "summary"]
      }
    }
  },
  required: ["topics"]
};


export const getAiResponse = async (question: string, fileNames: string[]): Promise<AiResponse> => {
  const model = "gemini-2.5-flash";

  const prompt = `You are StudyMate, an advanced AI assistant for students. Your task is to answer questions based *exclusively* on the content of the provided PDF documents.

Document Context:
You have access to the following documents: ${fileNames.join(', ')}.

User's Question:
"${question}"

Instructions:
1.  Carefully analyze the user's question.
2.  Synthesize a comprehensive answer using only the information available in the documents listed above.
3.  You MUST provide citations for every piece of information you use. Each citation must include the document name, page number, and a direct snippet of the source text.
4.  If the answer cannot be found within the provided documents, you MUST state: "I could not find an answer to your question in the provided documents." and provide no citations.
5.  Format your response strictly according to the provided JSON schema. Do not add any extra commentary or text outside of the JSON structure.
`;

  try {
    const result = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
      },
    });
    
    const responseText = result.text.trim();
    const parsedJson = JSON.parse(responseText) as AiResponse;

    if (!parsedJson.answer || !Array.isArray(parsedJson.citations)) {
      throw new Error("Invalid JSON structure received from API");
    }

    return parsedJson;

  } catch (error) {
    console.error("Gemini API call failed:", error);
    // Fallback response in case of API or parsing error
    return {
      answer: "I'm sorry, but I encountered an issue while processing your request. The AI model may have returned an unexpected response.",
      citations: [],
    };
  }
};

export const getSummary = async (fileName: string): Promise<TopicSummary[]> => {
  const model = "gemini-2.5-flash";

  const prompt = `You are an expert academic assistant. Your task is to analyze the document named "${fileName}" and create a structured summary of its key topics.

Instructions:
1.  Read through the document context for "${fileName}".
2.  Identify the main sections, chapters, or distinct topics discussed.
3.  For each identified topic, provide a concise but informative summary.
4.  The goal is to give the user a quick overview of the document's contents.
5.  Format your entire response as a single JSON object that adheres to the provided schema. Do not include any text outside of the JSON structure.
`;

  try {
    const result = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: summarySchema,
      },
    });

    const responseText = result.text.trim();
    const parsedJson = JSON.parse(responseText) as { topics: TopicSummary[] };

    if (!parsedJson.topics || !Array.isArray(parsedJson.topics)) {
        throw new Error("Invalid JSON structure for summary received from API");
    }

    return parsedJson.topics;

  } catch (error) {
    console.error(`Gemini API call for summary failed for ${fileName}:`, error);
    return [];
  }
};
