import { User } from '../types';

const USERS_KEY = 'studyMateUsers';
const SESSION_KEY = 'studyMateSession';

// This is a mock database. In a real application, this would be a secure backend service.
type StoredUser = User & { password: string };

// Helper to get users from localStorage
const getUsers = (): StoredUser[] => {
  const users = localStorage.getItem(USERS_KEY);
  return users ? JSON.parse(users) : [];
};

// Helper to save users to localStorage
const saveUsers = (users: StoredUser[]) => {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

export const register = async (userData: Omit<StoredUser, 'password'> & { password: string }): Promise<{ success: boolean; message: string; user: User | null }> => {
  return new Promise(resolve => {
    setTimeout(() => {
      const users = getUsers();
      if (users.find(u => u.username.toLowerCase() === userData.username.toLowerCase())) {
        resolve({ success: false, message: 'Username already exists.', user: null });
        return;
      }
      if (users.find(u => u.email.toLowerCase() === userData.email.toLowerCase())) {
        resolve({ success: false, message: 'An account with this email already exists.', user: null });
        return;
      }
      
      const newUser: StoredUser = {
          username: userData.username,
          email: userData.email,
          password: userData.password,
          phoneNumber: userData.phoneNumber
      };
      
      users.push(newUser);
      saveUsers(users);

      const userSessionData: User = {
          username: newUser.username,
          email: newUser.email,
          phoneNumber: newUser.phoneNumber
      };
      
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(userSessionData));
      resolve({ success: true, message: 'Registration successful!', user: userSessionData });
    }, 500); // Simulate network delay
  });
};

export const login = async (username: string, password: string): Promise<{ success: boolean; message: string; user: User | null }> => {
  return new Promise(resolve => {
    setTimeout(() => {
      const users = getUsers();
      const user = users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.password === password);
      if (user) {
        const { password, ...userSessionData } = user;
        sessionStorage.setItem(SESSION_KEY, JSON.stringify(userSessionData));
        resolve({ success: true, message: 'Login successful!', user: userSessionData });
      } else {
        resolve({ success: false, message: 'Invalid username or password.', user: null });
      }
    }, 500); // Simulate network delay
  });
};

export const logout = (): void => {
  sessionStorage.removeItem(SESSION_KEY);
};

export const getCurrentUser = (): User | null => {
  const userJson = sessionStorage.getItem(SESSION_KEY);
  if (!userJson) {
    return null;
  }
  try {
    return JSON.parse(userJson) as User;
  } catch (error) {
    console.error("Failed to parse user session", error);
    return null;
  }
};
