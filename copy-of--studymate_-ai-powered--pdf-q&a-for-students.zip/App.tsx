
import React, { useState, useCallback, useEffect } from 'react';
import { ChatMessage, PdfFile, ChatRole, User } from './types';
import { getAiResponse, getSummary } from './services/geminiService';
import { getCurrentUser, logout } from './services/authService';
import FileUpload from './components/FileUpload';
import PdfList from './components/PdfList';
import ChatWindow from './components/ChatWindow';
import Auth from './components/Auth';
import UserProfile from './components/UserProfile';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [uploadedFiles, setUploadedFiles] = useState<PdfFile[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    // Check for an active session when the app loads
    const user = getCurrentUser();
    if (user) {
      setCurrentUser(user);
    }
  }, []);
  
  const handleFilesUpload = useCallback(async (files: File[]) => {
    const newPdfFiles = files.map(file => ({
      name: file.name,
      size: file.size,
    }));
    setUploadedFiles(prevFiles => [...prevFiles, ...newPdfFiles]);
    
    setMessages(prevMessages => [...prevMessages, {
        role: ChatRole.SYSTEM,
        content: `Added ${files.length} file(s): ${files.map(f => f.name).join(', ')}`,
        citations: []
    }]);

    setIsLoading(true);
    try {
      for (const file of files) {
        const summaries = await getSummary(file.name);
        
        if (summaries.length > 0) {
          const formattedSummary = `Here is a summary of the key topics in **${file.name}**:\n\n` +
            summaries.map(s => `**- ${s.topic}:** ${s.summary}`).join('\n\n');
          
          const summaryMessage: ChatMessage = {
            role: ChatRole.AI,
            content: formattedSummary,
            citations: [],
          };
          setMessages(prev => [...prev, summaryMessage]);
        } else {
          const noSummaryMessage: ChatMessage = {
            role: ChatRole.SYSTEM,
            content: `Could not generate a summary for ${file.name}.`,
            citations: [],
          };
          setMessages(prev => [...prev, noSummaryMessage]);
        }
      }
    } catch (error) {
      console.error("Error generating summaries:", error);
      const errorMessage: ChatMessage = {
        role: ChatRole.AI,
        content: "Sorry, I encountered an error while trying to summarize the document(s).",
        citations: [],
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleSendMessage = useCallback(async (message: string) => {
    if (!message.trim() || isLoading) return;

    const userMessage: ChatMessage = { role: ChatRole.USER, content: message, citations: [] };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      if (uploadedFiles.length === 0) {
        const aiMessage: ChatMessage = {
          role: ChatRole.AI,
          content: "Please upload at least one PDF file before asking a question.",
          citations: [],
        };
        setMessages(prev => [...prev, aiMessage]);
        return;
      }

      const fileNames = uploadedFiles.map(f => f.name);
      const aiResponse = await getAiResponse(message, fileNames);
      
      const aiMessage: ChatMessage = {
        role: ChatRole.AI,
        content: aiResponse.answer,
        citations: aiResponse.citations,
      };
      setMessages(prev => [...prev, aiMessage]);

    } catch (error) {
      console.error("Error getting AI response:", error);
      const errorMessage: ChatMessage = {
        role: ChatRole.AI,
        content: "Sorry, I encountered an error while processing your request. Please try again.",
        citations: [],
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [isLoading, uploadedFiles]);

  const handleRemoveFile = useCallback((fileName: string) => {
    setUploadedFiles(prevFiles => prevFiles.filter(file => file.name !== fileName));
     setMessages(prevMessages => [...prevMessages, {
        role: ChatRole.SYSTEM,
        content: `Removed file: ${fileName}`,
        citations: []
    }]);
  }, []);

  const handleAuthSuccess = (user: User) => {
    setCurrentUser(user);
  };

  const handleLogout = () => {
    logout();
    setCurrentUser(null);
    // Reset app state on logout
    setUploadedFiles([]);
    setMessages([]);
    setIsLoading(false);
  };

  if (!currentUser) {
    return <Auth onAuthSuccess={handleAuthSuccess} />;
  }

  return (
    <div className="flex h-screen font-sans text-gray-800 dark:text-gray-200 bg-gray-100 dark:bg-gray-900">
      <aside className="w-1/4 max-w-xs bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <h1 className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">StudyMate</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Your AI-Powered PDF Assistant</p>
        </div>
        <div className="p-4 flex-grow overflow-y-auto">
          <FileUpload onFilesUpload={handleFilesUpload} />
          <PdfList files={uploadedFiles} onRemoveFile={handleRemoveFile} />
        </div>
        <div className="p-2 border-t border-gray-200 dark:border-gray-700">
            <UserProfile user={currentUser} onLogout={handleLogout} />
        </div>
      </aside>
      <main className="flex-1 flex flex-col">
        <ChatWindow messages={messages} isLoading={isLoading} onSendMessage={handleSendMessage} />
      </main>
    </div>
  );
};

export default App;
